#!/bin/bash
touch index.txt
echo '01' > serial.txt
